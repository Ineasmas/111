﻿using boevoe.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для IssuePage.xaml
    /// </summary>
    public partial class IssuePage : Page
    {
        int idbook;
        int idem;
        Entities.boevoeEntities db = boevoeEntities.GetContext();
        Books book;
        public IssuePage(int idSelected, int idEmploy)
        {
            InitializeComponent();
            idbook=idSelected;
            idem = idEmploy;
            book = db.Books.Where(a => a.idBook == idSelected).FirstOrDefault();
        }

        private void btEnter_Click(object sender, RoutedEventArgs e)
        {
            string phoneNumber = txtPhoneNumber.Text.Trim();
            try
            {
                Entities.boevoeEntities db = boevoeEntities.GetContext();
                IssuedBooks issuedBooks = new IssuedBooks();
                Books book = new Books();
                issuedBooks.idBook = idbook;
                issuedBooks.idReader =1;
                issuedBooks.IssueDate = DateTime.Now;
                issuedBooks.ReturnDate = DateTime.Now.AddDays(14);
                issuedBooks.idEmployee = idem;
                db.IssuedBooks.Add(issuedBooks);
                db.SaveChanges();
                MessageBox.Show("Успешно сохранено!");
                book.Status = false;
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
                NavigationService.Navigate(new Librarian(null));
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении данных");
            }
        }

        private void btCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Librarian(null));
        }
    }
}
