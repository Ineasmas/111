﻿using boevoe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для CheckIssue.xaml
    /// </summary>
    public partial class CheckIssue : Page
    {
        public CheckIssue()
        {
            InitializeComponent();
            mainGrid.ItemsSource = boevoeEntities.GetContext().IssuedBooks.Select(b => new { BookName=b.Books.Title, ReaderName=b.Readers.FirstName, b.IssueDate, b.ReturnDate, b.RealReturnDate, PhoneNumber= b.Readers.PhoneNumber, EmployeeName=b.Employees.FirstName, Dalay = (bool)b.Delay ? "Да" : "Нет", }).ToList();
        }

        private void ExitBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Librarian(null));
        }
    }
}
