﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using boevoe.Entities;
namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Page
    {
        
        public Admin(Employees currentEmployee)
        {
            InitializeComponent();
            mainGrid.ItemsSource = boevoeEntities.GetContext().Employees.ToList();
        }

        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEmployee());
        }

        private void changeBtn_Click(object sender, RoutedEventArgs e)
        {
            Employees employees = mainGrid.SelectedItem as Employees;
            if(employees!=null)
            {
                NavigationService.Navigate(new ChangeEmployee(employees.idEmployee));
            }
            mainGrid.ItemsSource = boevoeEntities.GetContext().Employees.ToList();

        }

        private void deleteBtn_Click(object sender, RoutedEventArgs e)
        {
            Employees employees = mainGrid.SelectedItem as Employees;
            Employees employee = boevoeEntities.GetContext().Employees.Find(employees.idEmployee);
            if (employees != null)
            {
                boevoeEntities.GetContext().Employees.Remove(employee);
                boevoeEntities.GetContext().SaveChanges();
                mainGrid.ItemsSource = boevoeEntities.GetContext().Employees.ToList();
                MessageBox.Show("Строка удалена");
            }
        }

        
    }
}
