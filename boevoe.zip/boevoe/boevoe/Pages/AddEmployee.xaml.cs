﻿using boevoe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Page
    {
        
        public AddEmployee()
        {
            InitializeComponent();
        }

        private void AccBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Entities.boevoeEntities db = boevoeEntities.GetContext();
                Employees employees = new Employees();
                employees.FirstName = NameBox.Text.Trim();
                employees.LastName = LastNameBox.Text.Trim();
                employees.BirthDate = BirthDateBox.Text.Trim();
                employees.Address = AddressBox.Text.Trim();
                employees.idEmployeeType = int.Parse(EmployeeTypeBox.Text.Trim());
                employees.Login = LoginBox.Text.Trim();
                employees.Password = PasswordBox.Text.Trim();
                db.Employees.Add(employees);
                db.SaveChanges();
                MessageBox.Show("Успешно сохранено!");
                NavigationService.Navigate(new Admin(null));
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении данных");
            }
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Admin(null));
        }
    }
}
