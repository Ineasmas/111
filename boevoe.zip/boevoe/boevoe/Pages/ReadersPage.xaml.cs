﻿using boevoe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using boevoe.Entities;
namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для Readers.xaml
    /// </summary>
    public partial class ReadersPage : Page
    {
        
        public ReadersPage()
        {
            InitializeComponent();
            mainGrid.ItemsSource = boevoeEntities.GetContext().Readers.ToList();
            
        }

        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddReader());

        }

        private void changeBtn_Click(object sender, RoutedEventArgs e)
        {
            Readers readers = mainGrid.SelectedItem as Readers;
            if (readers != null)
            {
                NavigationService.Navigate(new ChangeReader(readers.idReader));
            }
            mainGrid.ItemsSource = boevoeEntities.GetContext().Employees.ToList();
        }

        private void deleteBtn_Click(object sender, RoutedEventArgs e)
        {
            Readers readers = mainGrid.SelectedItem as Readers;
            Readers reader = boevoeEntities.GetContext().Readers.Find(readers.idReader);
            if (readers != null)
            {
                boevoeEntities.GetContext().Readers.Remove(reader);
                boevoeEntities.GetContext().SaveChanges();
                mainGrid.ItemsSource = boevoeEntities.GetContext().Readers.ToList();
                MessageBox.Show("Строка удалена");
            }
        }


    }
}
