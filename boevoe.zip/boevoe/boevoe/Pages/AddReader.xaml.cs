﻿using boevoe.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddReader.xaml
    /// </summary>
    public partial class AddReader : Page
    {
       
        public AddReader()
        {
            InitializeComponent();
           
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Librarian(null));
        }

        private void AccBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Entities.boevoeEntities db = boevoeEntities.GetContext();
                Readers reader = new Readers();
                reader.FirstName = NameBox.Text.Trim();
                reader.LastName = LastNameBox.Text.Trim();
                reader.BirthDate = BirthDateBox.Text.Trim();
                reader.Address = AddressBox.Text.Trim();
                reader.PhoneNumber = PhoneNumberBox.Text.Trim();
                db.Readers.Add(reader);
                db.SaveChanges();
                MessageBox.Show("Успешно сохранено!");
                NavigationService.Navigate(new ReadersPage());
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении данных");
            }
        }
    }
}
