﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using boevoe.Entities;
namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для Librarian.xaml
    /// </summary>
    public partial class Librarian : Page
    {
        Employees employee = new Employees();
        public Librarian(Employees currentEmployee)
        {
            InitializeComponent();
            var book=boevoeEntities.GetContext().Books.ToList();
            LViewProduct.ItemsSource= book;
            DataContext = this;
            txtAllAmount.Text=book.Count.ToString();
            employee=currentEmployee;
            txtFullname.Text = employee.FirstName.ToString() + " " + employee.LastName.ToString();
            
            UpdateData();
        }
        private void UpdateData()
        {
            var result = boevoeEntities.GetContext().Books.Select(b => new { b.Image, b.Title, AuthorName = b.Authors.AuthorName, GenreName = b.Genres.GenreName, b.ISBN, b.PublicationYear, Status = (bool)b.Status ? "Доступно" : "Недоступно", }).ToList();
            result = result.Where(p => p.Title.ToLower().Contains(txtSearch.Text.Trim().ToLower()) || p.AuthorName.ToLower().Contains(txtSearch.Text.Trim().ToLower())|| p.ISBN.ToLower().Contains(txtSearch.Text.Trim().ToLower())).ToList();
            LViewProduct.ItemsSource = result;
            txtResultAmount.Text = result.Count().ToString();

        }


        private void txtSearch_SelectionChanged(object sender, RoutedEventArgs e)
        {
            UpdateData();
        }

        private void Readers_Click(object sender, RoutedEventArgs e)
        {
            ReadersWindow readersWindow = new ReadersWindow();
            readersWindow.Show();
        }

        private void btnIssue_Click(object sender, RoutedEventArgs e)
        {

            int bookid = LViewProduct.SelectedIndex + 1;
            if (bookid != null)
            {
                NavigationService.Navigate(new IssuePage(bookid,employee.idEmployee));
            }
            LViewProduct.ItemsSource = boevoeEntities.GetContext().Books.Select(b => new { b.Image, b.Title, AuthorName = b.Authors.AuthorName, GenreName = b.Genres.GenreName, b.ISBN, b.PublicationYear, Status = (bool)b.Status ? "Доступно" : "Недоступно", }).ToList();
        }

        private void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            Entities.boevoeEntities db = boevoeEntities.GetContext();
            Books book = new Books();
            IssuedBooks issuedBooks = new IssuedBooks();
            int bookid = LViewProduct.SelectedIndex + 1;
            book.Status = true;
            issuedBooks.RealReturnDate = DateTime.Now;
            if (issuedBooks.ReturnDate <= issuedBooks.RealReturnDate)
                issuedBooks.Delay = false;
            else
                issuedBooks.Delay = true;
            db.Entry(book).State = EntityState.Modified;
            db.Entry(issuedBooks).State = EntityState.Modified;
            db.SaveChanges();
            NavigationService.Navigate(new ReadersPage());
        }
    }
}
