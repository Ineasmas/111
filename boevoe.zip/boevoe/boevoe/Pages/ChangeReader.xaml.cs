﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using boevoe.Entities;
namespace boevoe.Pages
{
    /// <summary>
    /// Логика взаимодействия для ChangeReader.xaml
    /// </summary>
    public partial class ChangeReader : Page
    {
        Entities.boevoeEntities db = boevoeEntities.GetContext();
        Readers reader;
        public ChangeReader(int idSelected)
        {
            InitializeComponent();
            reader = db.Readers.Where(a => a.idReader == idSelected).FirstOrDefault();
                NameBox.Text = reader.FirstName;
                LastNameBox.Text = reader.LastName;
                BirthDateBox.Text = reader.BirthDate;
                AddressBox.Text = reader.Address;
                PhoneNumberBox.Text = reader.PhoneNumber;

        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ReadersPage());
        }

        private void AccBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                reader.FirstName = NameBox.Text.Trim();
                reader.LastName = LastNameBox.Text.Trim();
                reader.BirthDate = BirthDateBox.Text.Trim();
                reader.Address = AddressBox.Text.Trim();
                reader.PhoneNumber = PhoneNumberBox.Text.Trim();
                db.Entry(reader).State = EntityState.Modified;
                db.SaveChanges();
                MessageBox.Show("Успешно сохранено!");
                NavigationService.Navigate(new ReadersPage());
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении данных");
            }
        }

    
    }
}
